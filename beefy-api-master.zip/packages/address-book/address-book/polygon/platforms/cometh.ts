export const cometh = {
  router: '0x93bcDc45f7e62f89a8e901DC4A0E2c6C427D9F25', // UniswapV2Router02
} as const;
