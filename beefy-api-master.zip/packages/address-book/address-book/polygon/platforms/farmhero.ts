export const farmhero = {
  chef: '0x8e5860DF653A467D1cC5b6160Dd340E8D475724E', // TransparentUpgradeableProxy
  multiFeeDistribution: '0x047e7D6E8f4b6dEBa0537A7c7e852C4272981075', // TransparentUpgradeableProxy
} as const;
