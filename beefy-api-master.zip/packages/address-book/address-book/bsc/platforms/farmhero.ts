export const farmhero = {
  chef: '0xDAD01f1d99191a2eCb78FA9a007604cEB8993B2D', // TransparentUpgradeableProxy
} as const;
