export const biswap = {
  masterchef: '0xDbc1A13490deeF9c3C12b44FE77b503c1B061739',
  router: '0x3a6d8cA21D1CF76F653A67577FA0D27453350dD8',
} as const;
