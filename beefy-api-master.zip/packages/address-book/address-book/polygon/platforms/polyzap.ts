export const polyzap = {
  router: '0x4aAEC1FA8247F85Dc3Df20F4e03FEAFdCB087Ae9', // PolyZapRouter
  masterchef: '0xB93C082bCfCCf5BAeA0E0f0c556668E25A41B896',
} as const;
