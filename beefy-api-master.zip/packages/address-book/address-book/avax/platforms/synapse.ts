export const synapse = {
  chef: '0x3a01521F8E7F012eB37eAAf1cb9490a5d9e18249', // MiniChefV2
};
