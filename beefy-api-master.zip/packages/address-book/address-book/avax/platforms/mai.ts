export const mai = {
  chef: '0xAB598434d0d0B1aDAf8311484A980d12169E035f',
} as const;
