export const fuseNetwork = {
  staker: '0x3014ca10b91cb3D0AD85fEf7A3Cb95BCAc9c0f79', // Consensus Contract
  rewarder: '0x63D4efeD2e3dA070247bea3073BCaB896dFF6C9B',
} as const;
