export const stellaswap = {
  router: '0xd0A01ec574D1fC6652eDF79cb2F880fd47D34Ab1', // UniswapV2Router02
  masterchef: '0xEDFB330F5FA216C9D2039B99C8cE9dA85Ea91c1E',
} as const;
