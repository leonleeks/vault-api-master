export const pancake = {
  masterchef: '0x73feaa1eE314F8c655E354234017bE2193C9E24E',
  router: '0x10ED43C718714eb63d5aA57B78B54704E256024E',
  oldRouter: '0x05fF2B0DB69458A0750badebc4f9e13aDd608C7F', // For historical reasons only, shouldn't use this for anything new
  bifiBnbLp: '0x3f1A9f3D9aaD8bD339eD4853F345d2eF89fbfE0c',
} as const;
