export const jet = {
  masterchef: '0x63d6EC1cDef04464287e2af710FFef9780B6f9F5',
  factory: '0x0eb58E5c8aA63314ff5547289185cC4583DfCBD5',
  router: '0xBe65b8f75B9F20f4C522e0067a3887FADa714800',
} as const;
