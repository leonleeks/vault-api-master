export const sushiFtm = {
  minichef: '0xf731202A3cf7EfA9368C2d7bD613926f7A144dB5', // MiniChefV2
  complexRewarderTime: '0xeaf76e3bD36680D98d254B378ED706cb0DFBfc1B',
  router: '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506',
} as const;
