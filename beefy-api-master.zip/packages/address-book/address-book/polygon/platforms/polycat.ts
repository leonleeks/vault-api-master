export const polycat = {
  masterchef: '0x8CFD1B9B7478E7B0422916B72d1DB6A9D513D734',
} as const;
