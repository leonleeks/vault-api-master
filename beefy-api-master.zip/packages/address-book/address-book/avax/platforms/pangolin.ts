export const pangolin = {
  router: '0xE54Ca86531e17Ef3616d22Ca28b0D458b6C89106',
  minichef: '0x1f806f7C8dED893fd3caE279191ad7Aa3798E928',
} as const;
