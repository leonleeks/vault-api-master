export const dfyn = {
  router: '0xA102072A4C07F06EC3B4900FDC4C7B80b6c57429',
} as const;
