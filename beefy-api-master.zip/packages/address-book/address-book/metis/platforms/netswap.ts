export const netswap = {
  router: '0x1E876cCe41B7b844FDe09E38Fa1cf00f213bFf56', // UniswapV2Router02
  masterchef: '0x9d1dbB49b2744A1555EDbF1708D64dC71B0CB052',
} as const;
