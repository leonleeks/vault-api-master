export const tethys = {
  router: '0x81b9FA50D5f5155Ee17817C21702C3AE4780AD09', // UniswapV2Router02
  masterchef: '0x54A8fB8c634dED694D270b78Cb931cA6bF241E21',
} as const;
