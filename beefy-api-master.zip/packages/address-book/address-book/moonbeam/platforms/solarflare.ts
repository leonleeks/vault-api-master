export const solarflare = {
  router: '0xd3B02Ff30c218c7f7756BA14bcA075Bf7C2C951e', // UniswapV2Router02
  masterchef: '0x995da7dfB96B4dd1e2bd954bE384A1e66cBB4b8c',
} as const;
