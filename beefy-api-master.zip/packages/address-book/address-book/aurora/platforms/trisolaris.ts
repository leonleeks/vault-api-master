export const trisolaris = {
  masterchef: '0x1f1Ed214bef5E83D8f5d0eB5D7011EB965D0D79B',
  minichef: '0x3838956710bcc9D122Dd23863a0549ca8D5675D6',
  router: '0x2CB45Edb4517d5947aFdE3BEAbF95A582506858B', // UniswapV2Router02
} as const;
