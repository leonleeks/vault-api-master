export const polywise = {
  masterchef: '0x62BA727e2449EE3BE0573b4b102D7090c5977BFB',
  timelock: '0x34926a6DeF7fFBC223747F4912eB38fd9B2609aB',
} as const;
