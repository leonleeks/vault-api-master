export const solidly = {
  router: '0xa38cd27185a464914D3046f0AB9d43356B34829D',
  voter: '0xdC819F5d05a6859D2faCbB4A44E5aB105762dbaE',
} as const;
