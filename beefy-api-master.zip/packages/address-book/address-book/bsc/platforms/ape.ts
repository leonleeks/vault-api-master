export const ape = {
  masterape: '0x5c8D727b265DBAfaba67E050f2f739cAeEB4A6F9',
  router: '0xcF0feBd3f17CEf5b47b0cD257aCf6025c5BFf3b7',
  factory: '0x0841BD0B734E4F5853f0dD8d7Ea041c241fb0Da6',
  bifiBananaLp: '0x2ce820319047c407cb952060Df5f7fb3D9A9a688',
} as const;
