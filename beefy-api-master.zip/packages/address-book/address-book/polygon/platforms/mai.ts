export default {
  chef: '0x574Fe4E8120C4Da1741b5Fd45584de7A5b521F0F',
} as const;
