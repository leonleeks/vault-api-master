export const sushiFuse = {
  minichef: '0x182CD0C6F1FaEc0aED2eA83cd0e160c8Bd4cb063', // MiniChefV2
  complexRewarderTime: '0xEF502259Dd5d497d082498912031E027c4515563',
  router: '0xF4d73326C13a4Fc5FD7A064217e12780e9Bd62c3',
} as const;
