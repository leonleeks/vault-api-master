export const sushi = {
  minichef: '0x67dA5f2FfaDDfF067AB9d5F025F8810634d84287', // MiniChefV2
  router: '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506', // UniswapV2Router02
  complexRewarderTime: '0x25836011Bbc0d5B6db96b20361A474CbC5245b45',
} as const;
