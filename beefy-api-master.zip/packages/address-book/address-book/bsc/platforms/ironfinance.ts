export const ironfinance = {
  masterchef: '0xC5a992dD7ba108e3349D2Fd8e8E126753Ca8Ce34',
  steelchef: '0x417E816Fae93a3136D5b4fE334eFF659e3941328',
  dndchef: '0x5d8b018BF2058Cd5264AA8c97A29E23cE660B3Ea',
  dndsinglechef: '0xAA8b49a4FC0A4C94087B2A01AaC760D89D491432',
} as const;
