export const wault = {
  masterchef: '0xC8Bd86E5a132Ac0bf10134e270De06A8Ba317BFe', // MasterChef
  router: '0x3a1D87f206D12415f5b0A33E786967680AAb4f6d', // UniswapV2Router02
} as const;
