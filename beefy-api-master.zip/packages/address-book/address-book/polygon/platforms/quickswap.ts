export const quickswap = {
  router: '0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff', // UniswapV2Router02
  wethBifiLp: '0x8b80417D92571720949fC22404200AB8FAf7775f',
} as const;
