export const vvs = {
  masterchef: '0xDccd6455AE04b03d785F12196B492b18129564bc', // Craftsman
  router: '0x145863Eb42Cf62847A6Ca784e6416C1682b1b2Ae', // UniswapV2Router02
  bifiCroLp: '0x1803E360393A472beC6E1A688BDF7048d3076b1A',
} as const;
