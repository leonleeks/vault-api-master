export const iron = {
  masterchef_LPs: '0x65430393358e55A658BcdE6FF69AB28cF1CbB77a',
  masterchef_IronTitanLP: '0xb444d596273C66Ac269C33c30Fbb245F4ba8A79d',
  masterchef_TitanSingleAsset: '0xa37DD1f62661EB18c338f18Cf797cff8b5102d8e',
} as const;
