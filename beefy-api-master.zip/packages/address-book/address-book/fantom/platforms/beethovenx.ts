export const spiritswap = {
  router: '0x20dd72Ed959b6147912C2e529F0a0C651c33c9ce',
  masterchef: '0x8166994d9ebBe5829EC86Bd81258149B87faCfd3',
} as const;
