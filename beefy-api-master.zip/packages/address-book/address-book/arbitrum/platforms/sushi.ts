export const sushi = {
  minichef: '0xF4d73326C13a4Fc5FD7A064217e12780e9Bd62c3', // MiniChefV2
  router: '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506', // UniswapV2Router02
  bifiEthLp: '0xcDA9B8e5867b5746755fE6E505B6300a76b2fAc3',
} as const;
